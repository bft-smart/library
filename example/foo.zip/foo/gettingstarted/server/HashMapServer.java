package foo.gettingstarted.server;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

import foo.gettingstarted.RequestType;

import bftsmart.tom.MessageContext;
import bftsmart.tom.ReplicaContext;
import bftsmart.tom.ServiceReplica;
import bftsmart.tom.server.defaultservices.DefaultSingleRecoverable;

public class HashMapServer extends DefaultSingleRecoverable {

	ServiceReplica replica = null;
	private ReplicaContext replicaContext;
	Map<String, String> table;

	public HashMapServer(int id) {
		replica = new ServiceReplica(id, this, this);
		table = new HashMap<String, String>();
	}
	
	public static void main(String[] args) {
		if(args.length < 1) {
			System.out.println("Usage: java HashMapServer <replica id>");
			System.exit(-1);
		}
		new HashMapServer(Integer.parseInt(args[0]));
	}

	@Override
	public void setReplicaContext(ReplicaContext replicaContext) {
		this.replicaContext = replicaContext;
	}

	@Override
	public byte[] appExecuteOrdered(byte[] command, MessageContext msgCtx) {
		ByteArrayInputStream in = new ByteArrayInputStream(command);
		DataInputStream dis = new DataInputStream(in);
		int reqType;
		try {
			reqType = dis.readInt();
			if(reqType == RequestType.PUT) {
				String key = dis.readUTF();
				String value = dis.readUTF();
				String oldValue = table.put(key, value);
				byte[] resultBytes = null;
				if(oldValue != null)
					resultBytes = oldValue.getBytes();
				return resultBytes;
			} else if(reqType == RequestType.REMOVE) {
				String key = dis.readUTF();
				String removedValue = table.remove(key);
				byte[] resultBytes = null;
				if(removedValue != null)
					resultBytes = removedValue.getBytes();
				return resultBytes;
			} else {
				System.out.println("Unknown request type: " + reqType);
				return null;
			}
		} catch (IOException e) {
			System.out.println("Exception reading data in the replica: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public byte[] executeUnordered(byte[] command, MessageContext msgCtx) {
		ByteArrayInputStream in = new ByteArrayInputStream(command);
		DataInputStream dis = new DataInputStream(in);
		int reqType;
		try {
			reqType = dis.readInt();
			if(reqType == RequestType.GET) {
				String key = dis.readUTF();
				String readValue = table.get(key);
				byte[] resultBytes = null;
				if(readValue != null)
					resultBytes = readValue.getBytes();
				return resultBytes;
			} else if(reqType == RequestType.SIZE) {
				int size = table.size();
				byte[] sizeInBytes = toBytes(size);
				return sizeInBytes;
			} else {
				System.out.println("Unknown request type: " + reqType);
				return null;
			}
		} catch (IOException e) {
			System.out.println("Exception reading data in the replica: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public void installSnapshot(byte[] state) {
		ByteArrayInputStream bis = new ByteArrayInputStream(state);
		try {
			ObjectInput in = new ObjectInputStream(bis);
			table = (Map<String, String>)in.readObject();
			in.close();
			bis.close();
		} catch (ClassNotFoundException e) {
			System.out.print("Coudn't find Map: " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			System.out.print("Exception installing the application state: " + e.getMessage());
			e.printStackTrace();
		}
	}

	@Override
	public byte[] getSnapshot() {
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream out = new ObjectOutputStream(bos);
			out.writeObject(table);
			out.flush();
			out.close();
			bos.close();
			return bos.toByteArray();
		} catch (IOException e) {
			System.out.println("Exception when trying to take a + " +
					"snapshot of the application state" + e.getMessage());
			e.printStackTrace();
			return new byte[0];
		}
	}


	private byte[] toBytes(int i) {
		byte[] result = new byte[4];
		result[0] = (byte) (i >> 24);
		result[1] = (byte) (i >> 16);
		result[2] = (byte) (i >> 8);
		result[3] = (byte) (i);
		return result;
	}

}
