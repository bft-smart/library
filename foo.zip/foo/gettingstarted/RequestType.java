package foo.gettingstarted;

public class RequestType {
    public static final int PUT = 1;
    public static final int GET = 2;
    public static final int REMOVE = 3;
    public static final int SIZE = 4;
}