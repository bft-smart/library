import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import threshsig.Dealer;
import threshsig.GroupKey;
import threshsig.KeyShare;
import threshsig.SigShare;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joao
 */
public class TestAuthMethods {
    
    public static int n;
    public static int k;
    public static int keysize;
    public static int datasize;
    public static int runs;
    
    public static SecretKeySpec secretkey;
    public static PublicKey puk;
    public static PrivateKey prk;
    public static GroupKey gk;
    public static KeyShare[] keys;
    
    public static byte[] b;
    public static byte[] data;
    public static byte[] signature;
    public static int[] S;
    public static SigShare[] sigs;
    


    public static void main(String[] args) {
        
        try {
            
            System.out.println("Generating threshold key and shares");
            
            n = Integer.parseInt(args[0]);
            k = Integer.parseInt(args[1]);
            
            sigs = new SigShare[k];
            S = new int[k];
            for (int i = 0; i < k; i++) S[i] = i + 1;

            keysize = Integer.parseInt(args[2]);
            datasize = Integer.parseInt(args[3]);
            runs = Integer.parseInt(args[4]);
            
            // Initialize a dealer with a keysize
            Dealer d = new Dealer(keysize);

            // Generate a set of key shares
            d.generateKeys(k, n);

            // This is the group key common to all shares, which
            // is not assumed to be trusted. Treat like a Public Key
            gk = d.getGroupKey();

            // The Dealer has the shares and is assumed trusted
            // This should be destroyed, unless you want to reuse the
            // Special Primes of the group key to generate a new set of
            // shares
            keys = d.getShares();

            //Normal RSA key pair
            System.out.println("Generating normal RSA key pair");
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(keysize);
            KeyPair kp = keyGen.generateKeyPair();
            puk = kp.getPublic();
            prk = kp.getPrivate();
            
            System.out.println("Generating normal secret key");
            secretkey = new SecretKeySpec("teste12345".getBytes(), "HmacSHA1");
         
            Mac mac = Mac.getInstance("HmacSHA1");
            
            Signature signatureEngine = null;
            signatureEngine = Signature.getInstance("SHA1withRSA");
            mac.init(secretkey);
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            
            System.out.println("Generating " + datasize + " bytes of data");
            data = new byte[datasize];
            (new Random()).nextBytes(data);

            long start = System.nanoTime();
            for (int i = 0; i < runs; i++) {
                b = md.digest(data);
            }
            long elapsed = System.nanoTime() - start;
            System.out.println("Average time to generate HASHs: (ms) " + (((float) elapsed / (float) runs) / 1000000) );
            System.out.println("HASHs per second: " + (float) runs / (((float) elapsed) / 1000000000) );

            System.out.println("Generating " + datasize + " bytes of data");
            data = new byte[datasize];
            (new Random()).nextBytes(data);

            start = System.nanoTime();
            for (int i = 0; i < runs; i++) {
                signature = mac.doFinal(data);
            }
            elapsed = System.nanoTime() - start;
            System.out.println("Average time to generate MACs: (ms) " + (((float) elapsed / (float) runs) / 1000000) );
            System.out.println("MACs per second: " + (float) runs / (((float) elapsed) / 1000000000) );

            signatureEngine.initSign(prk);
            start = System.nanoTime();
            
            System.out.println("Generating " + datasize + " bytes of data");
            data = new byte[datasize];
            (new Random()).nextBytes(data);

            for (int i = 0; i < runs; i++) {
                
                signatureEngine.update(data);
                signature = signatureEngine.sign();
            }
            elapsed = System.nanoTime() - start;
            System.out.println("Average time to generate RSA signatures: (ms) " + (((float) elapsed / (float) runs) / 1000000) );
            System.out.println("RSA signatures per second: " + (float) runs / (((float) elapsed) / 1000000000) );
            
            System.out.println("Generating " + datasize + " bytes of data");
            data = new byte[datasize];
            (new Random()).nextBytes(data);

            start = System.nanoTime();
            for (int i = 0; i < runs; i++) {
                sigs[0] = keys[S[0]].sign(data);
            }
            elapsed = System.nanoTime() - start;
            System.out.println("Average time to generate RSA threshold signatures: (ms) " + (((float) elapsed / (float) runs) / 1000000) );
            System.out.println("RSA threshold signatures per second: " + (float) runs / (((float) elapsed) / 1000000000) );
            
        } catch (Exception ex) {
            
            System.out.println("Sintax: TestAuthMethods <n> <k> <key size> <data size> <runs>");
            Logger.getLogger(TestAuthMethods.class.getName()).log(Level.SEVERE, null, ex);
        }

        
    }
}
