
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import threshsig.Dealer;
import threshsig.GroupKey;
import threshsig.KeyShare;
import threshsig.SigShare;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author joao
 */
public class Benchmark {

    private static int n;
    private static int k;
    private static int keysize;
    private static int runs;
    private static int threads;
    
    private static SecretKeySpec secretkey;
    private static PublicKey puk;
    private static PrivateKey prk;
    private static GroupKey gk;
    private static KeyShare[] keys;
    
    private static byte[] signature;
    private static byte[] data;
    //private static byte[] b;
    private static int[] S;
    private static SigShare[] sigs;
    
    public static final String RSAAlgoritm = "SHA1withRSA";
    public static final String HMACAlgoritm = "HmacSHA1";

    private static class SingleMACSign extends Thread {
        

        public void run() {

            try {
                
                Mac mac = Mac.getInstance(HMACAlgoritm);
                mac.init(secretkey);
                
                for (int i = 0; i < (runs / threads); i++) {
                    
                    //System.out.println("sign " + i);
                    signature = mac.doFinal(data);
   
                }
            } catch (InvalidKeyException ex) {                   
                Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    private static class SingleRSASign extends Thread {
        

        public void run() {

            try {
                
                Signature signatureEngine = null;
                signatureEngine = Signature.getInstance(RSAAlgoritm);
                signatureEngine.initSign(prk);
                
                for (int i = 0; i < (runs / threads); i++) {
                    
                    //System.out.println("sign " + i);
                    signatureEngine.update(data);
                    signature = signatureEngine.sign();
   
                }
            } catch (InvalidKeyException ex) {                   
                Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SignatureException ex) {
                Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
            }catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
            }

        }


    }

    private static class SingleRSAVerify extends Thread {
        

        public void run() {
            
            try {
                
                Signature signatureEngine = null;
                signatureEngine = Signature.getInstance(RSAAlgoritm);
                signatureEngine.initSign(prk);

                signatureEngine.initVerify(puk);
            
            //signature = new byte[64];
            for (int i = 0; i < (runs / threads); i++) {
                
                //System.out.println("verify " + i);
                signatureEngine.update(data);
                if (!signatureEngine.verify(signature))
                    System.out.println("Sig Failed to verify correctly");
                   
            }

            } catch (InvalidKeyException ex) {                   
                Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SignatureException ex) {
                Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
            }catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    private static class SingleThresholdSign extends Thread {

        public void run() {

            for (int i = 0; i < (runs / threads); i++) {
                
                
                try {
                    sigs[i % k] = keys[S[i % k]].sign(data);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
                //System.out.println("sign " + i);
            }
        }
    }

    private static class SingleThresholdVerify extends Thread {

        public void run() {

            for (int i = 0; i < (runs / threads); i++) {
                
                
                if (!SigShare.verify(data, sigs, k, n, gk.getModulus(), gk.getExponent())) {
                    System.out.println("Sig Failed to verify correctly");
                }
                //System.out.println("verify " + i);
            }

        }
    }
    
    public static void main(String[] args) {

        try {
                        
            System.out.println("Generating threshold key and shares");
            
            n = Integer.parseInt(args[0]);
            k = Integer.parseInt(args[1]);
           
            sigs = new SigShare[k];
            S = new int[k];
            for (int i = 0; i < k; i++) S[i] = i + 1;

            keysize = Integer.parseInt(args[2]);
            runs = Integer.parseInt(args[3]);
            threads = Integer.parseInt(args[4]);
            int datasize = Integer.parseInt(args[5]);

            data = new byte[datasize];
            (new Random()).nextBytes(data);

            System.out.println("Generating " + k + "/" + n + " threshold for "+ keysize + "-bit RSA public key and shares");
            
            // Initialize a dealer with a keysize
            Dealer d = new Dealer(keysize);

            // Generate a set of key shares
            d.generateKeys(k, n);

            // This is the group key common to all shares, which
            // is not assumed to be trusted. Treat like a Public Key
            gk = d.getGroupKey();

            // The Dealer has the shares and is assumed trusted
            // This should be destroyed, unless you want to reuse the
            // Special Primes of the group key to generate a new set of
            // shares
            keys = d.getShares();

            //Normal RSA key pair
            System.out.println("Generating normal "+ keysize + "-bit RSA key pair for " + RSAAlgoritm);
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(keysize);
            KeyPair kp = keyGen.generateKeyPair();
            puk = kp.getPublic();
            prk = kp.getPrivate();
            
            
            System.out.println("Generating normal secret key for " + HMACAlgoritm);
            secretkey = new SecretKeySpec("teste12345".getBytes(), HMACAlgoritm);
            
            ForkJoinPool fjp = new ForkJoinPool(threads);   
            Thread[] t = new Thread[threads];

            System.out.println("Starting benchmarks for " + runs + " run(s) with " + threads + " thread(s) for " + data.length + " byte(s)...");

            long start = System.currentTimeMillis();

            for(int i = 0; i < threads; i++) {
                fjp.execute(new SingleRSASign());
            }
            
            fjp.shutdown();
            fjp.awaitTermination(2, TimeUnit.DAYS);
              
            
            long elapsed = System.currentTimeMillis() - start;
            System.out.print("RSA signing total time: " + elapsed
                    + " (ms) / signs/sec: " + (int) ((float) runs / ((float) elapsed / 1000)));
            if (threads == 1) System.out.print(" / Average time: " + ((float) elapsed / (float) runs) + " ms");
            System.out.println();
            
            fjp = new ForkJoinPool(threads);
            start = System.currentTimeMillis();
            
            for(int i = 0; i < threads; i++) {
                fjp.execute(new SingleRSAVerify());
            }
            
            fjp.shutdown();
            fjp.awaitTermination(2, TimeUnit.DAYS);
            
            elapsed = System.currentTimeMillis() - start;
            
            System.out.print("RSA verification total time: " + elapsed
                    + " (ms) / verifies/sec: " + (int) ((float) runs / ((float) elapsed / 1000)));
            if (threads == 1) System.out.print(" / Average time: " + ((float) elapsed / (float) runs) + " ms");
            System.out.println();

            fjp = new ForkJoinPool(threads);
            start = System.currentTimeMillis();
            for(int i = 0; i < threads; i++) {
                fjp.execute(new SingleMACSign());
            }
            
            fjp.shutdown();
            fjp.awaitTermination(2, TimeUnit.DAYS);
            
            elapsed = System.currentTimeMillis() - start;
            System.out.print("HMAC creation total time: " + elapsed
                    + " (ms) / signs/sec: " + (int) ((float) runs / ((float) elapsed / 1000)));
            if (threads == 1) System.out.print(" / Average time: " + ((float) elapsed / (float) runs) + " ms");
            System.out.println();

            
            fjp = new ForkJoinPool(threads);
            start = System.currentTimeMillis();
            for(int i = 0; i < threads; i++) {
                fjp.execute(new SingleThresholdSign());
            }
            
            fjp.shutdown();
            fjp.awaitTermination(2, TimeUnit.DAYS);
            
            elapsed = System.currentTimeMillis() - start;
            System.out.print("Threshold signing total time: " + elapsed
                    + " (ms) / signs/sec: " + (int) ((float) runs / ((float) elapsed / 1000)));
            if (threads == 1) System.out.print(" / Average time: " + ((float) elapsed / (float) runs) + " ms");
            System.out.println();

            
            fjp = new ForkJoinPool(threads);
            start = System.currentTimeMillis();
            for(int i = 0; i < threads; i++) {
                fjp.execute(new SingleThresholdVerify());
            }

            fjp.shutdown();
            fjp.awaitTermination(2, TimeUnit.DAYS);
            
            elapsed = System.currentTimeMillis() - start;
            System.out.print("Threshold verification total time: " + elapsed
                    + " (ms) / signs/sec: " + (int) ((float) runs / ((float) elapsed / 1000)));
            if (threads == 1) System.out.print(" / Average time: " + ((float) elapsed / (float) runs) + " ms");
            System.out.println();

        } catch (Exception ex) {
            System.out.println("Sintax: Benchmark <n> <k> <key size> <runs> <threads> <data size>");
            Logger.getLogger(Benchmark.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
