package threshsig;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.math.BigInteger;

class Verifier implements Externalizable {
  private BigInteger z;

  private BigInteger c;

  private BigInteger groupVerifier;

  private BigInteger shareVerifier;

  public Verifier(final BigInteger z, final BigInteger c,
      final BigInteger shareVerifier, final BigInteger groupVerifier) {
    this.z = z;
    this.c = c;
    this.shareVerifier = shareVerifier;
    this.groupVerifier = groupVerifier;
  }
  
  public Verifier(){}

  public BigInteger getZ() {
    return this.z;
  }

  public BigInteger getShareVerifier() {
    return this.shareVerifier;
  }

  public BigInteger getGroupVerifier() {
    return this.groupVerifier;
  }

  public BigInteger getC() {
    return this.c;
  }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        
        byte[] b = z.toByteArray();
        out.writeInt(b.length);
        out.write(b);
        
        b = c.toByteArray();
        out.writeInt(b.length);
        out.write(b);
        
        b = shareVerifier.toByteArray();
        out.writeInt(b.length);
        out.write(b);
        
        b = groupVerifier.toByteArray();
        out.writeInt(b.length);
        out.write(b);
        
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        
        int l = in.readInt();
        byte[] b = new byte[l];
        in.readFully(b);
        z = new BigInteger(b);
        
        l = in.readInt();
        b = new byte[l];
        in.readFully(b);
        c = new BigInteger(b);
        
        l = in.readInt();
        b = new byte[l];
        in.readFully(b);
        shareVerifier = new BigInteger(b);
        
        l = in.readInt();
        b = new byte[l];
        in.readFully(b);
        groupVerifier = new BigInteger(b);
        
    }
}
